#ifndef CONVERSIONS_H
#define CONVERSIONS_H

int conversion(char Indic);

#endif
